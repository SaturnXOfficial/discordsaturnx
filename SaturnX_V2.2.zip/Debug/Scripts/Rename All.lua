local text = "Name"

for i,v in pairs(game.Players:GetPlayers()) do
    if v.Character and v.Character:FindFirstChildOfClass("Model") then
        v.Character:FindFirstChildOfClass("Model").ServerHandler:FireServer(text)
    end
end