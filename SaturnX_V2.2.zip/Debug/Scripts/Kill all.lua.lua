-- Sword Game OOFER --
-- I did not make this script, all credits to the owner.
-- Change _G.Stop to true if you want to stop --
 
_G.Stop = false
 
repeat game:GetService("RunService").RenderStepped:Wait()
for _,v in next, game:GetService("Players"):GetPlayers() do
if v ~= game:GetService("Players").LocalPlayer then
local char = v.Character or workspace:FindFirstChild(v.Name)
if char then
pcall(function()
char.Head.Anchored = true
char.Head.CFrame = game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame * CFrame.new(0,2,-2.5)
end)
end
end
end
until _G.Stop